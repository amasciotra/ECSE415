libraries used

import numpy as np
import cv2
import matplotlib.pyplot as plt
import skimage
from skimage import data, io, filters

